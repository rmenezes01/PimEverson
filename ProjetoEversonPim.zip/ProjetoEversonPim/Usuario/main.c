#include "stdio.h"
#include "stdlib.h"
#include "conio.h"
#include "string.h"

#define TAM_COD_USU 10
#define TAM_SENHA_USU 20

typedef struct{
  int conta;
  char nome[30];
  float saldo;
}Cliente;

struct Usuario {
    char cod_usu[TAM_COD_USU];
    char senha_usu[TAM_SENHA_USU];
}Usuario = {"admin","1234"};

int main()
{
  FILE *arquivo;
  Cliente cli;
  char continua[2];
  int c,ctreg;
  ctreg = 0;
  c=1;
  if((arquivo=fopen("teste.dat","ab"))==NULL)
  {
    printf("Arquivo nao pode ser aberto.\n");
    exit(1);
  }
  while(c!=0)
  {
    system("cls");
    printf("Conta: ");
    scanf("%d", &cli.conta);
    fflush(stdin);
    printf("Nome: ");
    gets(cli.nome);
    fflush(stdin);
    printf("Saldo: ");
    scanf("%f", &cli.saldo);
    fwrite(&cli, sizeof(Cliente),1,arquivo);
    printf("Continua? 0-1: ");
    scanf("%d", &c);
  }
  fclose(arquivo);
  if((arquivo=fopen("teste.dat","rb"))==NULL)
  {
    printf("Arquivo nao pode ser aberto.\n");
    exit(1);
  }
  printf("\n");
  while(fread(&cli, sizeof(Cliente), 1, arquivo))
  {
    ctreg++;
    printf("Conta: %d\n", cli.conta);
    printf("Nome: %s\n", cli.nome);
    printf("Saldo: %.2f\n\n", cli.saldo);
  }
  printf("Total de registros: %d\n",ctreg);
  fclose(arquivo);
  return 0;
}
