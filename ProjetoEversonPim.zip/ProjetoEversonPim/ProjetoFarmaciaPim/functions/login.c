#include <stdbool.h>
#include "../header/comum.h"

bool loginSistema(){
    chamaTelaLogin();
}

void chamaTelaLogin(){
    consoleTela();
    desenhaTelaPadrao();
    desenhaTelaLogin();
}

void desenhaTelaLogin(){
 setCursorXY(30,11);
 printf("Usuario:");
 char lv_user[15];
 gets(lv_user);
 if(lv_user == NULL){
    desenhaTelaLogin();
 }
}
