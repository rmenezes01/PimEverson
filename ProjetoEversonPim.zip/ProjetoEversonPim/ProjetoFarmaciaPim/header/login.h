#ifndef LOGIN_H_INCLUDED
#define LOGIN_H_INCLUDED

#endif // LOGIN_H_INCLUDED

bool loginSistema();
void chamaTelaLogin();
