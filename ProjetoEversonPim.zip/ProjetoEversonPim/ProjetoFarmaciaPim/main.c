#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <locale.h>


// Vari�veis globais
char exitLoop;
void main()
{
    exitLoop = false;
    while( exitLoop == false){
        if (loginSistema() == true){
            exitLoop = true;
        } else { exibeMensagemSistema("Usu�rio inv�lido!"); }
    };
}
